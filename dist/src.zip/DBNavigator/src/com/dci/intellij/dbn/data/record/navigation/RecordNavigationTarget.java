package com.dci.intellij.dbn.data.record.navigation;

public enum RecordNavigationTarget {
    VIEWER,
    EDITOR,
    ASK
}

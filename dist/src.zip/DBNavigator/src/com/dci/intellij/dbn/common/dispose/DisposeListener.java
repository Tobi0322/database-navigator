package com.dci.intellij.dbn.common.dispose;

public interface DisposeListener {
    void beforeDisposing();
}

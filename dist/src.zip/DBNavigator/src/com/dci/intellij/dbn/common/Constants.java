package com.dci.intellij.dbn.common;

public interface Constants {
    String DBN_TITLE_PREFIX = "DB Navigator - ";
}

package com.dci.intellij.dbn.browser.options;

public enum BrowserDisplayMode {
    SIMPLE,
    TABBED

}

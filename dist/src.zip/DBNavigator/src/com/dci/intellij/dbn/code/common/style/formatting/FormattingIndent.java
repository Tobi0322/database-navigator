package com.dci.intellij.dbn.code.common.style.formatting;

import com.dci.intellij.dbn.common.options.setting.SettingsUtil;
import com.intellij.formatting.Indent;
import org.jdom.Element;

public enum FormattingIndent {
    NORMAL(Indent.getNormalIndent()),
    CONTINUE(Indent.getContinuationIndent()),
    NONE(Indent.getNoneIndent()),
    ABSOLUTE_NONE(Indent.getAbsoluteNoneIndent()),
    NOT_SPECIFIED(null);

    private Indent indent;

    private FormattingIndent(Indent indent) {
        this.indent = indent;
    }

    public Indent getIndent() {
        return indent;
    }

    public static FormattingIndent get(Element element) {
        return SettingsUtil.getEnumAttribute(element, "formatting-indent", NOT_SPECIFIED);
    }
}

package com.dci.intellij.dbn.code.common.lookup;

import com.dci.intellij.dbn.code.common.completion.CodeCompletionContext;
import com.intellij.codeInsight.completion.CompletionResultSet;
import com.intellij.codeInsight.lookup.LookupValueWithUIHint;
import com.intellij.codeInsight.lookup.PresentableLookupValue;
import com.intellij.openapi.util.Iconable;

public interface LookupValue extends LookupValueWithUIHint, PresentableLookupValue, Iconable {
    public void createLookupItems(CompletionResultSet resultSet, CodeCompletionContext completionContext, boolean insertParenthesis);

}

package com.dci.intellij.dbn.data.export;

public enum DataExportFormat {
    SQL,
    EXCEL,
    HTML,
    XML,
    CSV,
    CUSTOM
}

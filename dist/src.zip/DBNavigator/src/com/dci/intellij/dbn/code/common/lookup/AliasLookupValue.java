package com.dci.intellij.dbn.code.common.lookup;

import com.dci.intellij.dbn.code.common.completion.CodeCompletionContext;
import com.intellij.codeInsight.completion.CompletionResultSet;

import javax.swing.*;
import java.awt.*;

public class AliasLookupValue implements LookupValue {

    private String name;
    private boolean isDefinition;

    public AliasLookupValue(String name, boolean isDefinition) {
        this.name = name;
        this.isDefinition = isDefinition;
    }

    public String getTypeHint() {
        return isDefinition ? "alias def" : "alias ref";
    }

    public void createLookupItems(CompletionResultSet resultSet, CodeCompletionContext completionContext, boolean insertParenthesis) {
        resultSet.addElement(new DBLookupItem(this, getPresentation(), completionContext));
    }

    public Color getColorHint() {
        return Color.RED;
    }

    public boolean isBold() {
        return false;
    }

    public String getPresentation() {
        return name;
    }

    public Icon getIcon(int flags) {
        return null;
    }
}
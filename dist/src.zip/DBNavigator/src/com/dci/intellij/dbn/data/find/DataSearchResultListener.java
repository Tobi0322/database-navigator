package com.dci.intellij.dbn.data.find;

public interface DataSearchResultListener {
    void searchResultUpdated(DataSearchResult searchResult);
}

package com.dci.intellij.dbn.browser.ui;

public interface ToolTipProvider {
    String getToolTip();
}

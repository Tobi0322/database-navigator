package com.dci.intellij.dbn.common.ui.table.model;

public interface DataModelListener {
    void modelChanged();
}

package com.dci.intellij.dbn.common;

import java.awt.Color;

public interface Colors {
    Color DSE_CELL_BACKGROUND_DISABLED = new Color(245, 245, 245);
    Color DSE_CELL_BACKGROUD_ERROR = new Color(255, 240, 240);
    Color DSE_POPUP_BACKGROUD_ERROR = new Color(255, 170, 170);

    Color LIGHT_BLUE = new Color(235, 244, 254);

}

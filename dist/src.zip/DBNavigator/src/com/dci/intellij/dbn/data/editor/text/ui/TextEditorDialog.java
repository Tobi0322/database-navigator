package com.dci.intellij.dbn.data.editor.text.ui;

import com.dci.intellij.dbn.common.ui.DBNDialog;
import com.dci.intellij.dbn.common.util.MessageUtil;
import com.dci.intellij.dbn.data.editor.text.TextEditorAdapter;
import com.dci.intellij.dbn.data.editor.ui.UserValueHolder;
import com.intellij.openapi.editor.event.DocumentEvent;
import com.intellij.openapi.editor.event.DocumentListener;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.Nullable;

import javax.swing.Action;
import javax.swing.JComponent;
import java.sql.SQLException;

public class TextEditorDialog extends DBNDialog implements DocumentListener {
    private TextEditorForm mainForm;

    private TextEditorDialog(Project project, TextEditorAdapter textEditorAdapter) throws SQLException {
        super(project, "Edit LOB content (column " + textEditorAdapter.getUserValueHolder().getName() + ")", true);
        UserValueHolder userValueHolder = textEditorAdapter.getUserValueHolder();
        mainForm = new TextEditorForm(this, userValueHolder, textEditorAdapter);
        getCancelAction().putValue(Action.NAME, "Close");
        getOKAction().setEnabled(false);
        setModal(false);
        init();
    }

    protected String getDimensionServiceKey() {
        return "DBNavigator.LOBDataEditor";
    }

    @Override
    public JComponent getPreferredFocusedComponent() {
        return mainForm.getEditorComponent();
    }

    public static void show(Project project, TextEditorAdapter textEditorAdapter) {
        try {
            TextEditorDialog dialog = new TextEditorDialog(project, textEditorAdapter);
            dialog.show();
        } catch (SQLException e) {
            MessageUtil.showErrorDialog("Could not load LOB content from database.", e);
        }
    }

    protected final Action[] createActions() {
        return new Action[]{
                getOKAction(),
                getCancelAction(),
                getHelpAction()
        };
    }

    @Override
    protected void doOKAction() {
        super.doOKAction();
        try {
            mainForm.writeUserValue();
        } catch (SQLException e) {
            MessageUtil.showErrorDialog("Could not write LOB content to database.", e);
        }
    }

    @Nullable
    protected JComponent createCenterPanel() {
        return mainForm.getComponent();
    }

    public void beforeDocumentChange(DocumentEvent event) {

    }

    public void documentChanged(DocumentEvent event) {
        getCancelAction().putValue(Action.NAME, "Cancel");
        getOKAction().setEnabled(true);
    }

    @Override
    protected void dispose() {
        super.dispose();
        mainForm.dispose();
    }
}

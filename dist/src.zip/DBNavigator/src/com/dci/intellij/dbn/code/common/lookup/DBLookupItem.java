package com.dci.intellij.dbn.code.common.lookup;

import com.dci.intellij.dbn.code.common.completion.CodeCompletionContext;
import com.dci.intellij.dbn.code.common.completion.options.sorting.CodeCompletionSortingSettings;
import com.dci.intellij.dbn.common.util.NamingUtil;
import com.intellij.codeInsight.completion.InsertHandler;
import com.intellij.codeInsight.lookup.LookupItem;
import org.jetbrains.annotations.NotNull;


public class DBLookupItem extends LookupItem {
    public DBLookupItem(LookupValue lookupValue, @NotNull String text, CodeCompletionContext completionContext) {
        super(lookupValue, NamingUtil.unquote(text));
        setIcon(lookupValue.getIcon(0));
        if (lookupValue.isBold()) setBold();
        setAttribute(LookupItem.TYPE_TEXT_ATTR, lookupValue.getTypeHint());
        setLookupString(text);
        setPresentableText(NamingUtil.unquote(text));
        CodeCompletionSortingSettings sortingSettings = completionContext.getCodeCompletionSettings().getSortingSettings();
        if (sortingSettings.isEnabled()) {
            setPriority(sortingSettings.getSortingIndexFor(lookupValue));
        }
    }

    @NotNull
    @Override
    public Object getObject() {
        return this;
    }

    @Override
    public InsertHandler getInsertHandler() {
        return super.getInsertHandler();
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof DBLookupItem) {
            DBLookupItem lookupItem = (DBLookupItem) o;
            return lookupItem.getLookupString().equals(getLookupString());
        }

        return false;
    }

    @Override
    public int hashCode() {
        return getLookupString().hashCode();
    }
}

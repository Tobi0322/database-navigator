package com.dci.intellij.dbn.data.editor.ui;

import java.util.List;

public interface ListPopupValuesProvider {
    List<String> getValues();
}

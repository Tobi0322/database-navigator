package com.dci.intellij.dbn.code.common.completion;

import com.dci.intellij.dbn.common.lookup.ConsumerStoppedException;
import com.dci.intellij.dbn.common.lookup.LookupConsumer;
import com.dci.intellij.dbn.language.common.DBLanguage;
import com.dci.intellij.dbn.language.common.element.TokenElementType;
import com.dci.intellij.dbn.object.common.DBObject;
import com.intellij.codeInsight.completion.CompletionResultSet;

import java.util.Collection;

public class CodeCompletionLookupConsumer implements LookupConsumer {
    private CompletionResultSet result;
    private CodeCompletionContext context;
    private DBLanguage language;
    boolean addParenthesis;

    public CodeCompletionLookupConsumer(CompletionResultSet result, CodeCompletionContext context, DBLanguage language) {
        this.result = result;
        this.context = context;
        this.language = language;
    }

    @Override
    public void consume(Object object) throws ConsumerStoppedException {
        check();
        if (object instanceof DBObject) {
            DBObject dbObject = (DBObject) object;
            dbObject.getLookupValue(language).createLookupItems(result, context, addParenthesis);
        } else if (object instanceof TokenElementType) {
            TokenElementType tokenElementType = (TokenElementType) object;
            tokenElementType.getLookupValue(language).createLookupItems(result, context, addParenthesis);
        }
    }

    public void consume(Collection objects) throws ConsumerStoppedException {
        check();
        for (Object object : objects) {
            consume(object);
        }
    }

    public void setAddParenthesis(boolean addParenthesis) {
        this.addParenthesis = addParenthesis;
    }

    @Override
    public void check() throws ConsumerStoppedException {
        if (result.isStopped()) {
            throw new ConsumerStoppedException();
        }
    }
}

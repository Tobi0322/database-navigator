package com.dci.intellij.dbn.data.editor.ui;

public enum TextFieldPopupType {
    TEXT_EDITOR,
    CALENDAR,
    VALUE_LIST

}

package com.dci.intellij.dbn.code.common.lookup;

import com.dci.intellij.dbn.code.common.completion.BasicInsertHandler;
import com.dci.intellij.dbn.code.common.completion.BracketsInsertHandler;
import com.dci.intellij.dbn.code.common.completion.CodeCompletionContext;
import com.dci.intellij.dbn.code.common.completion.CodeCompletionContributor;
import com.dci.intellij.dbn.code.common.style.DBLCodeStyleManager;
import com.dci.intellij.dbn.code.common.style.options.CodeStyleCaseOption;
import com.dci.intellij.dbn.code.common.style.options.CodeStyleCaseSettings;
import com.dci.intellij.dbn.language.common.DBLanguage;
import com.dci.intellij.dbn.language.sql.SQLLanguage;
import com.dci.intellij.dbn.object.DBSynonym;
import com.dci.intellij.dbn.object.common.DBObject;
import com.dci.intellij.dbn.object.common.DBVirtualObject;
import com.intellij.codeInsight.completion.CompletionResultSet;

import javax.swing.Icon;
import java.awt.Color;

public class DBObjectLookupValue implements LookupValue {
    private DBLanguage language;
    private DBObject object;
    private String typeHint;

    public DBObjectLookupValue(DBObject object, DBLanguage language) {
        this.object = object;
        this.language = language;
    }

    public void createLookupItems(CompletionResultSet resultSet, CodeCompletionContext completionContext, boolean insertParenthesis) {
        String presentation = getPresentation();
        boolean isDummyToken = presentation.contains(CodeCompletionContributor.DUMMY_TOKEN);

        if (object instanceof DBVirtualObject && isDummyToken) {
            return;
        }
        if (completionContext.showBothCases()) {
            createLookupItem(resultSet, presentation.toUpperCase(), completionContext, insertParenthesis);
            createLookupItem(resultSet, presentation.toLowerCase(), completionContext, insertParenthesis);
        } else {
            createLookupItem(resultSet, presentation, completionContext, insertParenthesis);
        }
    }


    private void createLookupItem(CompletionResultSet resultSet, String presentation, CodeCompletionContext completionContext, boolean insertParenthesis) {
        String lookupItemValue = needsQuotes() ? completionContext.getIdentifierQuoteChar() + presentation + completionContext.getIdentifierQuoteChar() : presentation;
        DBLookupItem lookupItem = new DBLookupItem(this, lookupItemValue, completionContext);
        /*if (needsQuotes()) {
            lookupItem.setAttribute(LookupItem.INSERT_HANDLER_ATTR, insertParenthesis ?
                            QuotesAndBracketsInsertHandler.INSTANCE :
                            QuotesInsertHandler.INSTANCE);

        } else {
            lookupItem.setAttribute(LookupItem.INSERT_HANDLER_ATTR, insertParenthesis ?
                            BracketsInsertHandler.INSTANCE :
                            BasicInsertHandler.INSTANCE);
        }*/
        lookupItem.setInsertHandler(insertParenthesis ?
                            BracketsInsertHandler.INSTANCE :
                            BasicInsertHandler.INSTANCE);
        resultSet.addElement(lookupItem);
    }

    public DBObject getObject() {
        return object;
    }

    private boolean needsQuotes() {
        String name = object.getName();
        return  name.indexOf('#') > -1 ||
                name.indexOf('.') > -1 ||
                object.getLanguageDialect(SQLLanguage.INSTANCE).isReservedWord(name);
    }

    public String getTypeHint() {
        if (typeHint == null) {
            DBObject parentObject = object.getParentObject();

            String typePrefix = "";
            if (object instanceof DBSynonym) {
                DBSynonym synonym = (DBSynonym) object;
                typePrefix = synonym.getUnderlyingObject().getTypeName() + " ";
            }

            typeHint = parentObject == null ?
                    typePrefix + object.getTypeName() :
                    typePrefix + object.getTypeName() + " (" +
                       parentObject.getTypeName() + " " +
                       parentObject.getName() + ")";
        }
        return typeHint;
    }

    public Color getColorHint() { return null;}

    public boolean isBold() {
        return false;
    }

    public String getPresentation() {
        CodeStyleCaseSettings styleCaseSettings = DBLCodeStyleManager.getInstance(object.getProject()).getCodeStyleCaseSettings(language);
        CodeStyleCaseOption caseOption = styleCaseSettings.getObjectCaseOption();
        return caseOption.changeCase(object.getName());
    }

    public Icon getIcon(int flags) {
        return object.getIcon(flags);
    }
}

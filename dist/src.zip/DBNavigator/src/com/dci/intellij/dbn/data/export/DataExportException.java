package com.dci.intellij.dbn.data.export;

public class DataExportException extends Exception {
    public DataExportException(String message) {
        super(message);
    }
}

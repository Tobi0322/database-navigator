package com.dci.intellij.dbn.data.find;

public enum DataSearchDirection {
    UP, DOWN
}

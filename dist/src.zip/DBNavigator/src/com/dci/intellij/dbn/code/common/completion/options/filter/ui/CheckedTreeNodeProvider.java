package com.dci.intellij.dbn.code.common.completion.options.filter.ui;

import com.intellij.ui.CheckedTreeNode;

public interface CheckedTreeNodeProvider {
    CheckedTreeNode createCheckedTreeNode();

}

package com.dci.intellij.dbn.common.content;

public interface DynamicContentType {
}

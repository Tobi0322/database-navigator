package com.dci.intellij.dbn.common.lookup;

public class ConsumerStoppedException extends Exception {
}

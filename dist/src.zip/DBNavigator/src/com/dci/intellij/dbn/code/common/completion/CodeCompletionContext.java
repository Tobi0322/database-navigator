package com.dci.intellij.dbn.code.common.completion;

import com.dci.intellij.dbn.code.common.completion.options.CodeCompletionSettings;
import com.dci.intellij.dbn.code.common.completion.options.filter.CodeCompletionFilterSettings;
import com.dci.intellij.dbn.code.common.style.options.ProjectCodeStyleSettings;
import com.dci.intellij.dbn.connection.ConnectionHandler;
import com.dci.intellij.dbn.database.DatabaseCompatibilityInterface;
import com.dci.intellij.dbn.language.common.psi.LeafPsiElement;
import com.dci.intellij.dbn.language.common.psi.UnknownPsiElement;
import com.dci.intellij.dbn.options.GlobalProjectSettings;
import com.intellij.codeInsight.completion.CompletionParameters;
import com.intellij.codeInsight.completion.CompletionType;
import com.intellij.psi.PsiElement;

public class CodeCompletionContext {
    private boolean isSmart;
    private boolean showBothCases;
    private ProjectCodeStyleSettings codeStyleSettings;
    private CodeCompletionSettings codeCompletionSettings;
    private char identifierQuoteChar;
    private PsiElement sourceElement;
    private ConnectionHandler connectionHandler;


    public CodeCompletionContext(PsiElement sourceElement, ConnectionHandler connectionHandler,  CompletionParameters parameters) {
        this.isSmart = parameters.getCompletionType() == CompletionType.SMART;
        this.showBothCases =
                (sourceElement instanceof LeafPsiElement || 
                        sourceElement instanceof UnknownPsiElement) && sourceElement.getTextOffset() != parameters.getOffset();
        this.identifierQuoteChar = connectionHandler == null ? '"' : DatabaseCompatibilityInterface.getInstance(connectionHandler).getIdentifierQuotes();
        this.connectionHandler = connectionHandler;

        GlobalProjectSettings globalSettings = GlobalProjectSettings.getInstance(sourceElement.getProject());
        codeStyleSettings = globalSettings.getCodeStyleSettings();
        codeCompletionSettings = globalSettings.getCodeCompletionSettings();
        this.sourceElement = sourceElement;
    }

    public PsiElement getSourceElement() {
        return sourceElement;
    }

    public ConnectionHandler getConnectionHandler() {
        return connectionHandler;
    }

    public void setSmart(boolean smart) {
        isSmart = smart;
    }

    public boolean isSmart() {
        return isSmart;
    }

    public boolean showBothCases() {
        return showBothCases;
    }

    public char getIdentifierQuoteChar() {
        return identifierQuoteChar;
    }

    public ProjectCodeStyleSettings getCodeStyleSettings() {
        return codeStyleSettings;
    }

    public CodeCompletionSettings getCodeCompletionSettings() {
        return codeCompletionSettings;
    }

    public CodeCompletionFilterSettings getCodeCompletionFilterSettings() {
        return codeCompletionSettings.getFilterSettings().getFilterSettings(isSmart);
    }


}

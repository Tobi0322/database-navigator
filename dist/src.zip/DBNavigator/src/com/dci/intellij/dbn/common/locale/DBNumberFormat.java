package com.dci.intellij.dbn.common.locale;

public enum DBNumberFormat {
    GROUPED,
    UNGROUPED,
    CUSTOM
}

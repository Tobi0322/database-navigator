package com.dci.intellij.dbn.data.find;

public enum DataSearchResultScrollPolicy {
    VERTICAL,
    HORIZONTAL;
}

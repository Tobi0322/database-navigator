package com.dci.intellij.dbn.code.psql.style.options;

import com.dci.intellij.dbn.code.common.style.options.CodeStyleCaseSettings;

public class PSQLCodeStyleCaseSettings extends CodeStyleCaseSettings {


    public String getDisplayName() {
        return "PSQL_CASE_OPTIONS";
    }
}
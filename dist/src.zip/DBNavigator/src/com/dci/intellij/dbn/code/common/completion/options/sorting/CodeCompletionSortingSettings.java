package com.dci.intellij.dbn.code.common.completion.options.sorting;

import com.dci.intellij.dbn.code.common.completion.options.sorting.ui.CodeCompletionSortingSettingsForm;
import com.dci.intellij.dbn.code.common.lookup.AliasLookupValue;
import com.dci.intellij.dbn.code.common.lookup.DBObjectLookupValue;
import com.dci.intellij.dbn.code.common.lookup.LookupValue;
import com.dci.intellij.dbn.code.common.lookup.TokenTypeLookupValue;
import com.dci.intellij.dbn.common.options.Configuration;
import com.dci.intellij.dbn.common.options.setting.SettingsUtil;
import com.dci.intellij.dbn.language.common.TokenType;
import com.dci.intellij.dbn.object.common.DBObjectType;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.WriteExternalException;
import org.jdom.Element;

import java.util.ArrayList;
import java.util.List;

public class CodeCompletionSortingSettings extends Configuration<CodeCompletionSortingSettingsForm> {
    private boolean enabled = true;
    private List<CodeCompletionSortingItem> sortingItems = new ArrayList<CodeCompletionSortingItem>();

    public int getSortingIndexFor(LookupValue lookupValue) {
        if (lookupValue instanceof AliasLookupValue) {
            return -1;
        }
        if (lookupValue instanceof DBObjectLookupValue) {
            DBObjectLookupValue objectLookupValue = (DBObjectLookupValue) lookupValue;
            DBObjectType objectType = objectLookupValue.getObject().getObjectType();
            return getSortingIndexFor(objectType);
        }

        if (lookupValue instanceof TokenTypeLookupValue) {
            TokenTypeLookupValue tokenTypeLookupValue = (TokenTypeLookupValue) lookupValue;
            TokenType tokenType = tokenTypeLookupValue.getTokenType();
            return getSortingIndexFor(tokenType);
        }
        return 0;
    }

    public int getSortingIndexFor(DBObjectType objectType) {
        for (int i=0; i<sortingItems.size(); i++) {
            if (sortingItems.get(i).getObjectType() == objectType) {
                return sortingItems.size() - i;
            }
        }
        return 0;
    }

    public int getSortingIndexFor(TokenType tokenType) {
        for (int i=0; i<sortingItems.size(); i++) {
            if (sortingItems.get(i).getTokenTypeIdentifier() == tokenType.getTokenTypeIdentifier()) {
                return sortingItems.size() - i;
            }
        }
        return 0;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }


    public List<CodeCompletionSortingItem> getSortingItems() {
        return sortingItems;
    }

    public String getDisplayName() {
        return "Code completion sorting";
    }

    /*********************************************************
     *                     Configuration                     *
     *********************************************************/
    public CodeCompletionSortingSettingsForm createConfigurationEditor() {
        return new CodeCompletionSortingSettingsForm(this);
    }

    @Override
    public String getConfigElementName() {
        return "sorting";
    }

    public void readConfiguration(Element element) throws InvalidDataException {
        enabled = SettingsUtil.getBooleanAttribute(element, "enabled", enabled);
        for (Object child : element.getChildren()) {
            Element childElement = (Element) child;
            CodeCompletionSortingItem sortingItem = new CodeCompletionSortingItem();
            sortingItem.readConfiguration(childElement);
            if (sortingItems.contains(sortingItem)) {
                sortingItems.remove(sortingItem);
            }
            sortingItems.add(sortingItem);
        }
    }

    public void writeConfiguration(Element element) throws WriteExternalException {
        SettingsUtil.setBooleanAttribute(element, "enabled", enabled);
        for (CodeCompletionSortingItem sortingItem : sortingItems) {
            writeConfiguration(element, sortingItem);
        }
    }

}

package com.dci.intellij.dbn.connection;

public enum ConnectivityStatus {
    VALID,
    INVALID,
    UNKNOWN
}

package com.dci.intellij.dbn.data.ui.table.model;

import com.dci.intellij.dbn.common.ui.table.model.SortableDataModel;
import com.dci.intellij.dbn.common.ui.table.model.SortableDataModelState;
import com.dci.intellij.dbn.connection.ConnectionHandler;
import com.dci.intellij.dbn.connection.ConnectionUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ResultSetDataModel<T extends ResultSetDataModelRow> extends SortableDataModel<T> {
    protected ResultSet resultSet;
    protected ConnectionHandler connectionHandler;
    protected boolean resultSetExhausted = false;

    public ResultSetDataModel(ConnectionHandler connectionHandler) throws SQLException {
        super(connectionHandler.getProject());
        this.connectionHandler = connectionHandler;
    }

    public ResultSetDataModel(ResultSet resultSet, ConnectionHandler connectionHandler, int maxRecords) throws SQLException {
        super(connectionHandler.getProject());
        this.connectionHandler = connectionHandler;
        this.resultSet = resultSet;
        header = new ResultSetDataModelHeader(connectionHandler.getObjectBundle(), resultSet);
        fetchNextRecords(maxRecords, false);
    }

    protected T createRow(int resultSetRowIndex) throws SQLException {
        return (T) new ResultSetDataModelRow(this, resultSet);
    }

    public ResultSet getResultSet() {
        return resultSet;
    }

    public int fetchNextRecords(int records, boolean reset) throws SQLException {
        int originalRowCount = getRowCount();
        if (resultSetExhausted) return originalRowCount;

        int initialIndex = reset ? 0 : originalRowCount;
        int count = 0;

        List<T> oldRows = getRows();
        List<T> newRows = reset ? new ArrayList<T>(oldRows.size()) : new ArrayList<T>(oldRows);
        if (resultSet == null) {
            resultSetExhausted = true;
        } else {
            while (count < records) {
                if (resultSet.next()) {
                    if (isDisposed()) break;
                    count++;
                    T row = createRow(initialIndex + count);
                    newRows.add(row);
                } else {
                    resultSetExhausted = true;
                    break;
                }
            }
        }

        sort(newRows);
        setRows(newRows);

        if (reset) {
            // dispose old content
            for (T row : oldRows) {
                disposeRow(row);
            }
        }

        int newRowCount = getRowCount();

        if (newRowCount > originalRowCount) notifyRowsInserted(originalRowCount, newRowCount);
        if (newRowCount < originalRowCount) notifyRowsDeleted(newRowCount, originalRowCount);
        int updateIndex = Math.min(originalRowCount, newRowCount);
        if (updateIndex > 0) notifyRowsUpdated(0, updateIndex);

        return newRowCount;
    }

    protected void disposeRow(T row) {
        row.dispose();
    }

    public boolean isResultSetExhausted() {
        return resultSetExhausted;
    }

    public void closeResultSet() throws SQLException {
        ConnectionUtil.closeResultSet(resultSet);
    }

    public ConnectionHandler getConnectionHandler() {
        return connectionHandler;
    }

    @Override
    protected SortableDataModelState createState() {
        return new SortableDataModelState();
    }

    public boolean isReadonly() {
        return true;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return getColumnInfo(columnIndex).getDataType().getTypeClass();
    }

    @Override
    public void dispose() {
        super.dispose();
        ConnectionUtil.closeResultSet(resultSet);
        resultSet = null;
        connectionHandler = null;
    }
}

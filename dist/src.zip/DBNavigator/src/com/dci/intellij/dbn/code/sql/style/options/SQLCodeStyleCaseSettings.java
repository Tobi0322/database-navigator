package com.dci.intellij.dbn.code.sql.style.options;

import com.dci.intellij.dbn.code.common.style.options.CodeStyleCaseSettings;

public class SQLCodeStyleCaseSettings extends CodeStyleCaseSettings {


    public String getDisplayName() {
        return "SQL_CASE_OPTIONS";
    }
}

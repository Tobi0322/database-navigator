package com.dci.intellij.dbn.database.common;

import com.dci.intellij.dbn.data.type.DataTypeDefinition;

import java.util.List;

public interface DatabaseNativeDataTypes {
    List<DataTypeDefinition> list();
}

package com.dci.intellij.dbn.database.common.debug;

public class BreakpointOperationInfo extends BasicOperationInfo {
}
package com.dci.intellij.dbn.code.common.style.formatting;

import com.intellij.formatting.Indent;
import com.intellij.formatting.Spacing;
import com.intellij.formatting.Wrap;
import org.jdom.Element;

public class FormattingAttributes {
    private Indent indent;
    private Wrap wrap;
    private Spacing spacing;

    public FormattingAttributes() {
    }

    public FormattingAttributes(Element def) {
        if (def != null) {
            indent = FormattingIndent.get(def).getIndent();
            wrap = FormattingWrap.get(def).getWrap();
            spacing = FormattingSpacing.get(def).getSpacing();
        }
    }

    public boolean isEmpty() {
        return indent == null && wrap == null && spacing == null;
    }

    public Indent getIndent() {
        return indent;
    }

    public Wrap getWrap() {
        return wrap;
    }

    public Spacing getSpacing() {
        return spacing;
    }


}


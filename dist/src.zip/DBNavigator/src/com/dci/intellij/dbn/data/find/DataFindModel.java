package com.dci.intellij.dbn.data.find;

import com.intellij.find.FindModel;

public class DataFindModel extends FindModel{

}

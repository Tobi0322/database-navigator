package com.dci.intellij.dbn.code.common.style.formatting;

import com.dci.intellij.dbn.code.common.style.presets.CodeStylePreset;
import com.dci.intellij.dbn.common.options.setting.SettingsUtil;
import com.intellij.formatting.Wrap;
import org.jdom.Element;

public enum FormattingWrap {
    NORMAL(CodeStylePreset.WRAP_NONE),
    ALWAYS(CodeStylePreset.WRAP_ALWAYS),
    IF_LONG(CodeStylePreset.WRAP_IF_LONG),
    NOT_SPECIFIED(null);

    private Wrap wrap;

    private FormattingWrap(Wrap wrap) {
        this.wrap = wrap;
    }

    public Wrap getWrap() {
        return wrap;
    }

    public static FormattingWrap get(Element element) {
        return SettingsUtil.getEnumAttribute(element, "formatting-wrap", NOT_SPECIFIED);
    }
}

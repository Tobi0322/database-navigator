package com.dci.intellij.dbn.common.ui;

import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.Insets;

public interface Borders {
    Insets EMPTY_INSETS = new Insets(0, 0, 0, 0);
    Border EMPTY_BORDER = new EmptyBorder(EMPTY_INSETS);
}

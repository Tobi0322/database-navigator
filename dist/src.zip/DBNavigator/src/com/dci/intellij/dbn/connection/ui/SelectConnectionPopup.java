package com.dci.intellij.dbn.connection.ui;

public class SelectConnectionPopup {

}

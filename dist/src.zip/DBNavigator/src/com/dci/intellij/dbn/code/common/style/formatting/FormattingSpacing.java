package com.dci.intellij.dbn.code.common.style.formatting;

import com.dci.intellij.dbn.code.common.style.presets.CodeStylePreset;
import com.dci.intellij.dbn.common.options.setting.SettingsUtil;
import com.intellij.formatting.Spacing;
import org.jdom.Element;

public enum FormattingSpacing {
    NO_SPACE(CodeStylePreset.SPACING_NO_SPACE),
    ONE_SPACE(CodeStylePreset.SPACING_ONE_SPACE),
    ONE_LINE(CodeStylePreset.SPACING_EXACT_ONE_LINE),
    NOT_SPECIFIED(null);

    private Spacing spacing;

    private FormattingSpacing(Spacing spacing) {
        this.spacing = spacing;
    }

    public Spacing getSpacing() {
        return spacing;
    }

    public static FormattingSpacing get(Element element) {
        return SettingsUtil.getEnumAttribute(element, "formatting-spacing", NOT_SPECIFIED);
    }
}

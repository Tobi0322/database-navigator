package com.dci.intellij.dbn.code.common.completion.options.filter;

import com.dci.intellij.dbn.code.common.completion.options.filter.ui.CodeCompletionFiltersSettingsForm;
import com.dci.intellij.dbn.common.options.CompositeConfiguration;
import com.dci.intellij.dbn.common.options.Configuration;
import com.dci.intellij.dbn.language.common.TokenTypeIdentifier;
import com.dci.intellij.dbn.object.common.DBObjectType;

public class CodeCompletionFiltersSettings extends CompositeConfiguration<CodeCompletionFiltersSettingsForm> {
    private CodeCompletionFilterSettings basicFilterSettings;
    private CodeCompletionFilterSettings smartFilterSettings;

    public CodeCompletionFiltersSettings() {
        basicFilterSettings = new CodeCompletionFilterSettings(false);
        smartFilterSettings = new CodeCompletionFilterSettings(true);

    }

    public String getDisplayName() {
        return "Code completion filter";
    }

   /*********************************************************
    *                         Custom                        *
    *********************************************************/
    public CodeCompletionFilterSettings getFilterSettings(boolean smart) {
        return smart ? smartFilterSettings : basicFilterSettings;
    }

    public CodeCompletionFilterSettings getBasicFilterSettings() {
        return basicFilterSettings;
    }

    public CodeCompletionFilterSettings getSmartFilterSettings() {
        return smartFilterSettings;
    }

    boolean acceptRootObjects(boolean smart, DBObjectType objectType) {
        return smart ?
                smartFilterSettings.acceptRootObject(objectType) :
                basicFilterSettings.acceptRootObject(objectType);
    }

    boolean showReservedWords(boolean smart, TokenTypeIdentifier tokenTypeIdentifier) {
        return smart ?
                smartFilterSettings.acceptReservedWord(tokenTypeIdentifier) :
                basicFilterSettings.acceptReservedWord(tokenTypeIdentifier);
    }

    boolean showUserSchemaObjects(boolean smart, DBObjectType objectType) {
        return smart ?
                smartFilterSettings.acceptCurrentSchemaObject(objectType) :
                basicFilterSettings.acceptCurrentSchemaObject(objectType);
    }

    boolean acceptPublicSchemaObjects(boolean smart, DBObjectType objectType) {
        return smart ?
                smartFilterSettings.acceptPublicSchemaObject(objectType) :
                basicFilterSettings.acceptPublicSchemaObject(objectType);
    }

    boolean acceptAnySchemaObjects(boolean smart, DBObjectType objectType) {
        return smart ?
                smartFilterSettings.acceptAnySchemaObject(objectType) :
                basicFilterSettings.acceptAnySchemaObject(objectType);
    }

    /*********************************************************
    *                   Configuration                       *
    *********************************************************/
    protected CodeCompletionFiltersSettingsForm createConfigurationEditor() {
        return new CodeCompletionFiltersSettingsForm(this);
    }

    @Override
    public String getConfigElementName() {
        return "filters";
    }

    protected Configuration[] createConfigurations() {
        return new Configuration[] {
                basicFilterSettings,
                smartFilterSettings};
    }
}
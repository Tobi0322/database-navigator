package com.dci.intellij.dbn.code.common.style.formatting;

import com.dci.intellij.dbn.code.common.style.options.CodeStyleCustomSettings;
import com.dci.intellij.dbn.code.common.style.options.CodeStyleFormattingOption;
import com.dci.intellij.dbn.code.common.style.presets.CodeStylePreset;
import com.dci.intellij.dbn.language.common.DBLanguage;
import com.dci.intellij.dbn.language.common.element.ElementType;
import com.dci.intellij.dbn.language.common.element.QualifiedIdentifierElementType;
import com.dci.intellij.dbn.language.common.element.util.ElementTypeAttribute;
import com.dci.intellij.dbn.language.common.psi.*;
import com.intellij.formatting.*;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiComment;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiWhiteSpace;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class FormattingBlock implements Block {
    private PsiElement psiElement;
    private CodeStyleSettings codeStyleSettings;
    private CodeStyleCustomSettings codeStyleCustomSettings;
    private static final  List<Block> EMPTY_LIST = new ArrayList<Block>(0);
    private List<Block> subBlocks;
    private Block parent;
    private int index;

    private FormattingAttributes attributes;

    public FormattingBlock(
            CodeStyleSettings codeStyleSettings,
            CodeStyleCustomSettings codeStyleCustomSettings,
            PsiElement psiElement,
            Block parent, int index) {
        this.psiElement = psiElement;
        this.parent = parent;
        this.index = index;
        this.codeStyleSettings = codeStyleSettings;
        this.codeStyleCustomSettings = codeStyleCustomSettings;

        if (psiElement instanceof BasePsiElement) {
            BasePsiElement basePsiElement = (BasePsiElement) psiElement;
            ElementType baseElementType = basePsiElement.getElementType();
            attributes = baseElementType.getFormattingAttributes();
        }
    }

    @Nullable
    public Indent getIndent() {
        if (psiElement instanceof BasePsiElement){
            if (attributes != null && attributes.getIndent() != null) {
                return attributes.getIndent();
            }

            BasePsiElement basePsiElement = (BasePsiElement) psiElement;

            ElementType elementType  = basePsiElement.getElementType();
            if (elementType.is(ElementTypeAttribute.STATEMENT)) return Indent.getNormalIndent(true);
        }
        return Indent.getNoneIndent();
    }

    @Nullable
    public Wrap getWrap() {
        if (psiElement instanceof BasePsiElement){
            BasePsiElement basePsiElement = (BasePsiElement) psiElement;

            if (attributes != null && attributes.getWrap() != null) {
                Wrap wrap = attributes.getWrap();

                wrap = wrap == CodeStylePreset.WRAP_IF_LONG &&
                       basePsiElement.lookupEnclosingNamedPsiElement().approximateLength() > codeStyleSettings.RIGHT_MARGIN ?
                    CodeStylePreset.WRAP_ALWAYS :
                    CodeStylePreset.WRAP_NONE;
                return wrap;
            }

            for (CodeStyleFormattingOption option : codeStyleCustomSettings.getFormattingSettings().getOptions()) {
                CodeStylePreset preset = option.getPreset();
                if (preset.accepts(basePsiElement)) {
                    return preset.getWrap(basePsiElement, codeStyleSettings);
                }
            }
        }

        return CodeStylePreset.WRAP_NONE;
    }

    @Nullable
    public Spacing getSpacing(Block child1, Block child2) {
        FormattingBlock leftBlock = (FormattingBlock) child1;
        FormattingBlock rightBlock = (FormattingBlock) child2;

        PsiElement leftPsiElement = leftBlock.getPsiElement();
        PsiElement rightPsiElement = rightBlock.getPsiElement();

        if (leftPsiElement instanceof PsiComment || rightPsiElement instanceof PsiComment) {
            return null;
        }

        if (rightPsiElement.getParent() instanceof UnknownPsiElement) {
            return null;
        }
        
        ElementType parentElementType = getParentElementType(rightPsiElement);
        if (parentElementType instanceof QualifiedIdentifierElementType) {
            return CodeStylePreset.SPACING_NO_SPACE;
        }

        if (rightPsiElement instanceof BasePsiElement) {
            BasePsiElement basePsiElement = (BasePsiElement) rightPsiElement;
            List<CodeStyleFormattingOption> formattingOptions = codeStyleCustomSettings.getFormattingSettings().getOptions();
            for (CodeStyleFormattingOption formattingOption : formattingOptions) {
                CodeStylePreset preset = formattingOption.getPreset();
                if (preset.accepts(basePsiElement)) {
                    return preset.getSpacing(basePsiElement, codeStyleSettings);
                }
            }

            if (basePsiElement.getElementType().is(ElementTypeAttribute.STATEMENT)) {
                return CodeStylePreset.SPACING_LINE_BREAK;
            }
        }
        return null;
    }

    private BasePsiElement getParentPsiElement(PsiElement psiElement) {
        PsiElement parentPsiElement = psiElement.getParent();
        if (parentPsiElement instanceof BasePsiElement) {
            return (BasePsiElement) parentPsiElement;
        }
        return null;
    }

    private ElementType getParentElementType(PsiElement psiElement) {
        BasePsiElement parentPsiElement = getParentPsiElement(psiElement);
        if (parentPsiElement != null) {
            return parentPsiElement.getElementType();
        }
        return null;
    }

    @NotNull
    public TextRange getTextRange() {
        //return textRange;
        return psiElement.getTextRange();
    }

    @NotNull
    public synchronized List<Block> getSubBlocks() {
        if (subBlocks == null) {
            PsiElement child = psiElement.getFirstChild();
            while (child != null) {
                if (child instanceof BasePsiElement || child instanceof ChameleonPsiElement || child instanceof PsiComment) {
                    if (subBlocks == null) subBlocks = new ArrayList<Block>();
                    CodeStyleCustomSettings codeStyleCustomSettings = getCodeStyleSettings(child);
                    subBlocks.add(new FormattingBlock(codeStyleSettings, codeStyleCustomSettings, child, this, index));
                }

                child = child.getNextSibling();
            }

            if (subBlocks == null) subBlocks = EMPTY_LIST;
        }
        return subBlocks;
    }

    private CodeStyleCustomSettings getCodeStyleSettings(PsiElement child) {
        CodeStyleCustomSettings codeStyleCustomSettings = this.codeStyleCustomSettings;
        if (child instanceof ChameleonPsiElement) {
            ChameleonPsiElement element = (ChameleonPsiElement) child;
            DBLanguage language = (DBLanguage) PsiUtil.getLanguage(element);
            codeStyleCustomSettings = language.getCodeStyleSettings(psiElement.getProject());
        }
        return codeStyleCustomSettings;
    }

    @Nullable
    public Alignment getAlignment() {
        return Alignment.createAlignment();
    }

    @NotNull
    public ChildAttributes getChildAttributes(final int newChildIndex) {
        List<Block> subBlocks = getSubBlocks();
        if (newChildIndex > subBlocks.size() -1) {
            return new ChildAttributes(Indent.getNoneIndent(), Alignment.createAlignment());
        } else {
            Block child = getSubBlocks().get(newChildIndex);
            return new ChildAttributes(child.getIndent(), child.getAlignment());
        }
    }

    public boolean isIncomplete() {
        if (psiElement instanceof BasePsiElement) {
            BasePsiElement basePsiElement = (BasePsiElement) psiElement;
            return basePsiElement.hasErrors();
        }
        return false;
    }

    private boolean isPreviousIncomplete() {
        Block previous = getPreviousBlockInParent();
        return previous != null && previous.isIncomplete();
    }

    private boolean isParentIncomplete() {
        return parent != null && parent.isIncomplete();
    }

    public boolean isLeaf() {
        return psiElement instanceof IdentifierPsiElement ||
               psiElement instanceof TokenPsiElement ||
               psiElement instanceof PsiWhiteSpace;
    }


    public String toString() {
        return psiElement.toString();
    }


    public PsiElement getPsiElement() {
        return psiElement;
    }

    private Block getPreviousBlockInParent() {
        if (parent != null) {
            return index > 0 ? parent.getSubBlocks().get(index - 1) : null;
        }
        return null;
    }
}

package com.dci.intellij.dbn.data.record;

public enum ColumnSortingType {
    ALPHABETICAL,
    BY_INDEX
}

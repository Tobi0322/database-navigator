package com.dci.intellij.dbn.code.common.style.options.ui;

import com.dci.intellij.dbn.code.common.style.options.CodeStyleCaseSettings;
import com.dci.intellij.dbn.common.options.ui.ConfigurationEditorForm;
import com.dci.intellij.dbn.common.ui.UIForm;
import com.intellij.openapi.options.ConfigurationException;

import javax.swing.*;

public class CodeStyleCaseSettingsForm extends ConfigurationEditorForm<CodeStyleCaseSettings> implements UIForm {
    private JPanel mainPanel;
    private JComboBox keywordCaseComboBox;
    private JComboBox functionCaseComboBox;
    private JComboBox parameterCaseComboBox;
    private JComboBox objectCaseComboBox;
    private JComboBox datatypeCaseComboBox;
    private JCheckBox enableCheckBox;


    public CodeStyleCaseSettingsForm(CodeStyleCaseSettings settings) {
        super(settings);
        resetChanges();

        registerComponent(keywordCaseComboBox);
        registerComponent(functionCaseComboBox);
        registerComponent(parameterCaseComboBox);
        registerComponent(objectCaseComboBox);
        registerComponent(datatypeCaseComboBox);
        registerComponent(enableCheckBox);

        //Shortcut[] basicShortcuts = KeyUtil.getShortcuts("ReformatCode");
        //enableCheckBox.setText("Use on reformat code (" + KeymapUtil.getShortcutsText(basicShortcuts) + ")");
    }

    public JPanel getComponent() {
        return mainPanel;
    }

    public void applyChanges() throws ConfigurationException {
        CodeStyleCaseSettings settings = getConfiguration();
        settings.getKeywordCaseOption().setStyleCase(keywordCaseComboBox.getSelectedIndex());
        settings.getFunctionCaseOption().setStyleCase(functionCaseComboBox.getSelectedIndex());
        settings.getParameterCaseOption().setStyleCase(parameterCaseComboBox.getSelectedIndex());
        settings.getDatatypeCaseOption().setStyleCase(datatypeCaseComboBox.getSelectedIndex());
        settings.getObjectCaseOption().setStyleCase(objectCaseComboBox.getSelectedIndex());
        settings.setEnabled(enableCheckBox.isSelected());
    }

    public void resetChanges() {
        CodeStyleCaseSettings settings = getConfiguration();
        keywordCaseComboBox.setSelectedIndex(settings.getKeywordCaseOption().getStyleCase());
        functionCaseComboBox.setSelectedIndex(settings.getFunctionCaseOption().getStyleCase());
        parameterCaseComboBox.setSelectedIndex(settings.getParameterCaseOption().getStyleCase());
        datatypeCaseComboBox.setSelectedIndex(settings.getDatatypeCaseOption().getStyleCase());
        objectCaseComboBox.setSelectedIndex(settings.getObjectCaseOption().getStyleCase());
        enableCheckBox.setSelected(settings.isEnabled());
    }
}

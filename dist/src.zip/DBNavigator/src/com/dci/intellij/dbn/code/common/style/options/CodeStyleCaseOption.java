package com.dci.intellij.dbn.code.common.style.options;

import com.dci.intellij.dbn.common.options.PersistentConfiguration;
import com.dci.intellij.dbn.common.util.NamingUtil;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.WriteExternalException;
import org.jdom.Element;

public class CodeStyleCaseOption implements PersistentConfiguration {
    public static final int UPPER = 0;
    public static final int LOWER = 1;
    public static final int CAPITALIZED = 2;

    private String name;
    private int styleCase;

    public CodeStyleCaseOption(String id, int styleCase) {
        this.name = id;
        this.styleCase = styleCase;
    }

    public CodeStyleCaseOption() {
    }

    public String getName() {
        return name;
    }

    public int getStyleCase() {
        return styleCase;
    }

    public void setStyleCase(int styleCase) {
        this.styleCase = styleCase;
    }

    public String changeCase(String string) {
        return
            string == null ? null :
            styleCase == UPPER ? string.toUpperCase() :
            styleCase == LOWER ? string.toLowerCase() :
            styleCase == CAPITALIZED ? NamingUtil.capitalize(string) : string;

    }

    /*********************************************************
     *                   JDOMExternalizable                  *
     *********************************************************/
    public void readConfiguration(Element element) throws InvalidDataException {
        name = element.getAttributeValue("name");
        String style = element.getAttributeValue("value");
        styleCase =
                style.equals("upper") ? UPPER :
                style.equals("lower") ? LOWER :
                style.equals("capitalized") ? CAPITALIZED : UPPER;
    }

    public void writeConfiguration(Element element) throws WriteExternalException {
        String value =
                styleCase == UPPER ? "upper" :
                styleCase == LOWER ? "lower" :
                styleCase == CAPITALIZED ? "capitalized" : null;

        element.setAttribute("name", name);
        element.setAttribute("value", value);
    }
}

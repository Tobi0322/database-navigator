package com.dci.intellij.dbn.common.message;

public enum MessageType {
    INFO,
    WARNING,
    ERROR
}

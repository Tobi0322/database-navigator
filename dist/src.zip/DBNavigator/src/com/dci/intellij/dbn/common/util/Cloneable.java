package com.dci.intellij.dbn.common.util;

public interface Cloneable<T> extends java.lang.Cloneable{
    T clone();
}
